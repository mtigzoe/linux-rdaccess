"""Companion metadata, independent of the general-purpose RDAccess add-on."""

NAME = "linuxRdAccess"
SUMMARY = "Linux Remote Access Companion"
VERSION = "20261014.0.3"
MINIMUM_NVDA = "2026.1.0"
LAST_TESTED_NVDA = "2026.2.0"
AUTHOR = "linux-rdaccess contributors; derived from RDAccess by Leonard de Ruijter"
URL = "https://github.com/mtigzoe/linux-rdaccess"
DESCRIPTION = (
	"Linux semantic braille and explicitly authorized five-minute local test sessions for NVDA Remote Access."
)
