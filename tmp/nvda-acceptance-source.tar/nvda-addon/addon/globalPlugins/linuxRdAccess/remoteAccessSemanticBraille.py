# Extracted for linux-rdaccess on 2026-10-12; original GPL-2.0-or-later license retained.
# RDAccess: Remote Desktop Accessibility for NVDA
# Copyright 2026
# License: GNU General Public License version 2.0 or later

from __future__ import annotations

import contextlib
import inspect
import typing
import unicodedata
import weakref

import braille
import config
import inputCore
import queueHandler
from logHandler import log

from . import a11y
from .remoteA11yObject import RemoteA11yObject

NATIVE_BRAILLE_VERSION = 1
MESSAGE_VERSION = 1
_MAX_MESSAGE_LENGTH = 256
_HELLO_CALLBACK = "msg_lrd_a11y_hello"
_FOCUS_CALLBACK = "msg_lrd_a11y_focus"
_MESSAGE_CALLBACK = "msg_lrd_a11y_message"
_FALLBACK_CALLBACK = "msg_lrd_a11y_fallback"
_BUILTIN_TYPES = {
	"lrd_a11y_hello",
	"lrd_a11y_focus",
	"lrd_a11y_message",
	"lrd_a11y_fallback",
}


class _UnavailableRoutingObserver:
	def __init__(self, emit):
		self._emit = emit

	def install(self, _handler):
		with contextlib.suppress(Exception):
			self._emit("outcome_unknown")

	def mark(self, _event):
		pass

	def index(self):
		return None

	def inRoute(self):
		return False

	def close(self):
		pass


def _sanitizeMessage(text) -> str | None:
	"""Bound and normalize temporary messages without logging their contents."""
	if not isinstance(text, str):
		return None
	text = "".join(
		" " if unicodedata.category(ch)[0] in ("C", "Z") else ch for ch in text[:_MAX_MESSAGE_LENGTH]
	)
	text = " ".join(text.split())
	return text or None


def _builtinRemoteState() -> tuple[typing.Any | None, typing.Any | None]:
	"""Return NVDA's built-in Remote Access client and active leader transport."""
	try:
		import _remoteClient
	except Exception:
		return None, None
	client = getattr(_remoteClient, "_remoteClient", None)
	if client is None:
		return None, None
	return client, getattr(client, "leaderTransport", None)


class RemoteAccessSemanticBrailleBridge:
	"""Render Linux semantic focus with NVDA's own braille engine.

	For current built-in NVDA Remote Access, unknown protocol message types are
	rejected by Transport.parse before normal handlers can register them. This
	bridge therefore wraps only the active leader transport instance, consumes
	the linux-rdaccess extension messages, and delegates every standard message
	to the original parser unchanged.

	Legacy Orca Remote/TeleNVDA-style transports which expose callback_manager
	continue to use their native callback registration mechanism.

	This bridge deliberately avoids NVDA gainFocus events: Orca Remote already
	provides speech, so semantic focus is presented to braille only. The local
	Windows focus object is left untouched.
	"""

	def __init__(self, transport):
		if not callable(getattr(transport, "send", None)):
			raise TypeError("Remote Access transport cannot send messages")
		self._transport = transport
		self._manager = getattr(transport, "callback_manager", None)
		self._session = 0
		self._transportGeneration = 0
		self._controlGeneration = 0
		self._negotiated = False
		self._terminated = False
		self._objects: dict[str, RemoteA11yObject] = {}
		self._focusId: str | None = None
		self._lastNode = None
		self._lastFocus: a11y.FocusMessage | None = None
		self._focusReceiptLoggedSession: int | None = None
		self._focusPresentationState: tuple[bool, bool, bool] | None = None
		self._transportEvents = []
		self._originalParse = None
		self._installedParse = None
		self._client = None
		self._originalSetReceivingBraille = None
		self._semanticBrailleInputInstalled = False
		self._messageOwner: tuple[typing.Any, int, int] | None = None
		self._messageHooks = []
		self._routingTrace = None
		try:
			from .routingOutcomes import NativeRoutingObserver

			self._routingObserver = NativeRoutingObserver(self._outcomesActive, self._traceOutcome)
		except Exception:
			self._routingObserver = _UnavailableRoutingObserver(self._traceOutcome)
		self._dismissObservation = None

		if self._manager is not None and callable(getattr(self._manager, "register_callback", None)):
			self._manager.register_callback(_HELLO_CALLBACK, self._onHello)
			self._manager.register_callback(_FOCUS_CALLBACK, self._onFocus)
			self._manager.register_callback(_MESSAGE_CALLBACK, self._onMessage)
			self._manager.register_callback(_FALLBACK_CALLBACK, self._onFallback)
		else:
			self._installBuiltInTransport()

		self._installBuiltInBrailleOwnership()
		self._installMessageHooks()
		for name in ("transportDisconnected", "transportClosing"):
			event = getattr(transport, name, None)
			if event is not None and callable(getattr(event, "register", None)):
				event.register(self._onTransportDisconnected)
				self._transportEvents.append(event)

	@property
	def transport(self):
		return self._transport

	def _installBuiltInTransport(self) -> None:
		serializer = getattr(self._transport, "serializer", None)
		originalParse = getattr(self._transport, "parse", None)
		if (
			serializer is None
			or not callable(getattr(serializer, "deserialize", None))
			or not callable(originalParse)
		):
			raise TypeError("Remote Access transport has no supported inbound extension surface")
		self._originalParse = originalParse

		def parse(line):
			transportGeneration = self._transportGeneration
			controlGeneration = self._controlGeneration
			try:
				message = serializer.deserialize(line)
			except Exception:
				return originalParse(line)
			messageType = message.get("type") if isinstance(message, dict) else None
			if messageType not in _BUILTIN_TYPES:
				return originalParse(line)
			payload = dict(message)
			payload.pop("type", None)
			# Relay servers can add an origin field. It is transport metadata,
			# not part of the semantic payload.
			payload.pop("origin", None)
			if messageType == "lrd_a11y_hello":
				handler = self._onHello
			elif messageType == "lrd_a11y_focus":
				handler = self._onFocus
			elif messageType == "lrd_a11y_message":
				handler = self._onMessage
			else:
				handler = self._onFallback
			queueHandler.queueFunction(
				queueHandler.eventQueue,
				self._dispatchOnMainThread,
				transportGeneration,
				controlGeneration,
				handler,
				payload,
			)

		self._installedParse = parse
		self._transport.parse = parse

	def _dispatchOnMainThread(self, generation: int, controlGeneration: int, handler, payload: dict) -> None:
		if self._terminated or generation != self._transportGeneration:
			return
		if handler == self._onMessage and controlGeneration != self._controlGeneration:
			return
		handler(**payload)

	def _isCurrentTransport(self) -> bool:
		return getattr(self._transport, "connected", True) and (
			self._client is None or getattr(self._client, "leaderTransport", None) is self._transport
		)

	def _isCurrentSession(self, session: int) -> bool:
		return (
			not self._terminated
			and self._negotiated
			and session == self._session
			and self._isCurrentTransport()
		)

	def _clearFocus(self) -> None:
		self._messageOwner = None
		self._objects.clear()
		self._focusId = None
		self._lastNode = None
		self._lastFocus = None
		self._focusPresentationState = None

	def _onTransportDisconnected(self, **_kwargs) -> None:
		if self._terminated:
			return
		# Invalidate IO-thread messages immediately, including parsed messages
		# still waiting for dispatch when this transport reconnects.
		self._transportGeneration += 1
		self._session += 1
		self._negotiated = False
		self._lastFocus = None
		queueHandler.queueFunction(queueHandler.eventQueue, self._finishDisconnectOnMainThread, self._session)

	def _finishDisconnectOnMainThread(self, session: int) -> None:
		if self._terminated or session != self._session:
			return
		self._clearFocus()
		self._removeSemanticBrailleInput(restoreStock=False)

	def _leaderSession(self):
		client = self._client
		if client is None or getattr(client, "leaderTransport", None) is not self._transport:
			return None
		return getattr(client, "leaderSession", None)

	def _traceRouting(
		self, event, *, gesture=None, index=None, offset=None, sameFocus=None, outcome=False
	) -> None:
		"""Record only typed routing metadata when separately opted-in consent is active."""
		recorder = None
		try:
			recorder = self._routingTrace
			if recorder is None or not recorder.active():
				return
			if self._terminated or not self._isCurrentTransport():
				return
			handler = braille.handler
			buffer = getattr(handler, "buffer", None)
			main = getattr(handler, "mainBuffer", None)
			message = getattr(handler, "messageBuffer", None)
			kind = "unavailable" if handler is None else "other"
			if message is not None and buffer is message:
				kind = "message"
			elif main is not None and buffer is main:
				kind = "main"
			if gesture is not None:
				cells = getattr(gesture, "cellIndexes", None)
				if cells is not None:
					index = cells[0] if cells else None
				else:
					index = getattr(gesture, "routingIndex", None)
			index = index if type(index) is int and 0 <= index <= 1023 else None
			offset = offset if type(offset) is int and 0 <= offset <= 8192 else None
			owner = self._messageOwner
			if (
				event == "message_dismissed"
				and owner is None
				and getattr(self._client, "sendingKeys", None) is not True
			):
				return
			record = recorder.recordOutcome if outcome else recorder.record
			record(
				event,
				buffer=kind,
				linux_owned=bool(
					owner is not None
					and owner[0] is handler
					and owner[1] == self._session
					and owner[2] == self._controlGeneration
				),
				control=getattr(self._client, "sendingKeys", None) is True,
				capture=getattr(getattr(inputCore, "manager", None), "_captureFunc", None) is not None,
				semantic_input=self._semanticBrailleInputInstalled is True,
				index=index,
				offset=offset,
				same_focus=sameFocus if type(sameFocus) is bool else None,
			)
		except Exception:
			# Diagnostics must never change a gesture or log arbitrary exception data.
			if recorder is not None:
				with contextlib.suppress(Exception):
					recorder.noteDropped(outcomes=True) if outcome else recorder.noteDropped()

	def _outcomesActive(self):
		try:
			return (
				self._routingTrace is not None
				and self._routingTrace.active()
				and self._negotiated
				and self._isCurrentSession(self._session)
				and (self._client is None or getattr(self._client, "sendingKeys", False))
			)
		except Exception:
			return False

	def _traceOutcome(self, event, **fields):
		if not self._outcomesActive():
			return
		try:
			self._routingObserver.mark(event)
			fields.setdefault("index", self._routingObserver.index())
			self._traceRouting(event, outcome=True, **fields)
		except Exception:
			with contextlib.suppress(Exception):
				self._routingTrace.noteDropped(outcomes=True)

	def _traceRouteReceived(self, gesture, *, native: bool) -> bool:
		try:
			if self._routingTrace is None or not self._routingTrace.active():
				return False
			isRoute = (
				native
				or type(getattr(gesture, "routingIndex", None)) is int
				or bool(
					getattr(gesture, "cellIndexes", None),
				)
			)
			if isRoute:
				self._traceRouting("route_received", gesture=gesture)
			return isRoute
		except Exception:
			with contextlib.suppress(Exception):
				self._routingTrace.noteDropped()
			return False

	def _handleSemanticBrailleGesture(self, gesture) -> bool:
		"""Keep NVDA-coordinate braille commands local; forward other gestures."""
		try:
			from globalCommands import commands
		except Exception:
			return True
		localScripts = {
			commands.script_braille_toggleTether,
			commands.script_braille_cycleReviewRoutingMovesSystemCaret,
			commands.script_braille_toggleFocusContextPresentation,
			commands.script_braille_toggleShowCursor,
			commands.script_braille_toggleSpeakOnRouting,
			commands.script_braille_cycleCursorShape,
			commands.script_braille_cycleShowMessages,
			commands.script_braille_cycleShowSelection,
			commands.script_braille_cycleUnicodeNormalization,
			commands.script_braille_scrollBack,
			commands.script_braille_scrollForward,
			commands.script_braille_routeTo,
			commands.script_braille_reportFormatting,
			commands.script_braille_previousLine,
			commands.script_braille_nextLine,
		}
		# Range selection is available only in newer NVDA versions.
		selectRange = getattr(commands, "script_braille_selectRange", None)
		if selectRange is not None:
			localScripts.add(selectRange)
		script = getattr(gesture, "script", None)
		isRoute = self._traceRouteReceived(gesture, native=script == commands.script_braille_routeTo)
		scriptFunction = getattr(script, "__func__", None)
		# BrailleExtender binds its own equivalent pan scripts, rather than
		# GlobalCommands' bound methods. Keep only these known aliases local;
		# arbitrary same-named scripts must still follow normal forwarding.
		isBrailleExtenderPan = (
			scriptFunction is not None
			and scriptFunction.__module__ == "globalPlugins.brailleExtender"
			and scriptFunction.__name__ in ("script_braille_scrollBack", "script_braille_scrollForward")
		)
		if script in localScripts or isBrailleExtenderPan:
			if script == commands.script_braille_routeTo and self._queueOwnedMessageRoute(gesture):
				return False
			if script == commands.script_braille_routeTo:
				self._traceRouting("route_native", gesture=gesture)
				self._traceOutcome("native_delegated", gesture=gesture)
				if getattr(getattr(inputCore, "manager", None), "_captureFunc", None) is not None:
					self._traceOutcome("outcome_unknown", gesture=gesture)
				handler = braille.handler
				if (
					self._lastFocus is not None
					and handler is not None
					and getattr(handler, "buffer", None) is getattr(handler, "mainBuffer", None)
				):
					return self._guardQueuedMainRoute(gesture, handler)
			# executeGesture queues its script after this decision. Restore Linux
			# regions first if a local Windows update replaced the shared buffer.
			# The decider can run on an input thread, so do not touch braille here.
			if self._lastFocus is not None:
				queueHandler.queueFunction(
					queueHandler.eventQueue,
					self._recoverFocusBeforeGesture,
					self._session,
					self._controlGeneration,
					isRoute,
				)
			elif isRoute:
				self._traceOutcome("outcome_unknown", gesture=gesture)
			return True
		session = self._leaderSession()
		forward = getattr(session, "handleDecideExecuteGesture", None)
		if callable(forward):
			if isRoute:
				self._traceRouting("route_delegated", gesture=gesture)
				self._traceOutcome("outcome_unknown", gesture=gesture)
			return forward(gesture)
		if isRoute:
			self._traceOutcome("outcome_unknown", gesture=gesture)
		return True

	def _guardQueuedMainRoute(self, gesture, handler) -> bool:
		"""Bind a native routing script to the focus/control visible at input."""
		execute = getattr(gesture, "executeScript", None)
		if not callable(execute):
			# Native InputGesture provides this hook. Do not let an unsupported
			# gesture fall through to an unguarded route against a later buffer.
			self._traceOutcome("route_discarded", gesture=gesture)
			return False
		session, generation, focus = self._session, self._controlGeneration, self._lastFocus
		mainBuffer = handler.mainBuffer

		def current():
			return (
				self._isCurrentSession(session)
				and generation == self._controlGeneration
				and self._lastFocus is focus
				and braille.handler is handler
				and getattr(handler, "mainBuffer", None) is mainBuffer
				and getattr(handler, "buffer", None) is mainBuffer
				and (self._client is None or getattr(self._client, "sendingKeys", False))
			)

		def executeCurrent(script):
			if current():
				self._recoverFocusBeforeGesture(session, generation, observeRouting=True)
				if current():
					return execute(script)
			self._traceRouting("route_discarded", gesture=gesture)
			self._traceOutcome("route_discarded", gesture=gesture)

		try:
			# Keep gesture.script unchanged: NVDA still owns speech effects,
			# input help, capture, script metadata and queue ordering. Its queued
			# callback enters executeScript only if those stages allow execution.
			gesture.executeScript = executeCurrent
		except Exception:
			self._traceOutcome("route_discarded", gesture=gesture)
			return False
		return True

	def _queueOwnedMessageRoute(self, gesture) -> bool:
		# Preserve NVDA's own input-help and gesture-capture handling. Its
		# executeGesture checks capture only after the decider runs.
		if getattr(getattr(inputCore, "manager", None), "_captureFunc", None) is not None:
			return False
		owner = self._messageOwner
		if owner is None:
			return False
		handler, session, generation = owner
		messageBuffer = getattr(handler, "messageBuffer", None)
		if (
			handler is not braille.handler
			or messageBuffer is None
			or getattr(handler, "buffer", None) is not messageBuffer
			or not self._isCurrentSession(session)
			or generation != self._controlGeneration
			or (self._client is not None and not getattr(self._client, "sendingKeys", False))
		):
			return False
		cells = getattr(gesture, "cellIndexes", None)
		if cells is not None and not cells:
			return False
		index = cells[0] if cells else getattr(gesture, "routingIndex", None)
		if type(index) is not int or index < 0:
			return False
		try:
			regions = tuple(weakref.ref(region) for region in messageBuffer.regions)
		except TypeError:
			# Stock NVDA TextRegion supports weak references. Leave custom
			# region implementations to their normal native script.
			return False
		# Do not mutate braille on the input thread or retain message text.
		# Suppress the original script: its later buffer lookup could otherwise
		# route into Linux after this message's timer or another gesture dismisses it.
		self._traceRouting("route_guarded", index=index)
		queueHandler.queueFunction(queueHandler.eventQueue, self._routeOwnedMessage, owner, regions, index)
		return True

	def _routeOwnedMessage(self, owner, regions, index: int) -> None:
		handler, session, generation = owner
		messageBuffer = getattr(handler, "messageBuffer", None)
		if (
			owner is not self._messageOwner
			or handler is not braille.handler
			or not self._isCurrentSession(session)
			or generation != self._controlGeneration
			or (self._client is not None and not getattr(self._client, "sendingKeys", False))
			or messageBuffer is None
			or getattr(handler, "buffer", None) is not messageBuffer
		):
			self._traceRouting("route_discarded", index=index)
			self._traceOutcome("route_discarded", index=index)
			return
		current = tuple(messageBuffer.regions)
		if len(current) != len(regions) or any(ref() is not region for ref, region in zip(regions, current)):
			self._traceRouting("route_discarded", index=index)
			self._traceOutcome("route_discarded", index=index)
			return
		self._routingObserver.install(handler)
		handler.routeTo(index)

	def _installSemanticBrailleInput(self) -> None:
		if self._semanticBrailleInputInstalled:
			return
		session = self._leaderSession()
		if session is None:
			return
		# Replace stock Remote Access's all-gesture forwarding while semantic
		# presentation is active. Otherwise NVDA-local routing coordinates would
		# be misinterpreted as Orca raw-cell coordinates on Linux.
		with contextlib.suppress(Exception):
			session.unregisterBrailleInput()
		inputCore.decide_executeGesture.register(self._handleSemanticBrailleGesture)
		self._semanticBrailleInputInstalled = True

	def _removeSemanticBrailleInput(self, *, restoreStock: bool) -> None:
		if self._semanticBrailleInputInstalled:
			with contextlib.suppress(Exception):
				inputCore.decide_executeGesture.unregister(self._handleSemanticBrailleGesture)
			self._semanticBrailleInputInstalled = False
		if not restoreStock:
			return
		session = self._leaderSession()
		client = self._client
		if session is not None and client is not None and getattr(client, "sendingKeys", False):
			with contextlib.suppress(Exception):
				session.registerBrailleInput()

	def _installBuiltInBrailleOwnership(self) -> None:
		client, leaderTransport = _builtinRemoteState()
		if client is None or leaderTransport is not self._transport:
			return
		original = getattr(client, "setReceivingBraille", None)
		if not callable(original):
			return
		self._client = client
		self._originalSetReceivingBraille = original
		try:
			localMachine = getattr(client, "localMachine", None)
			dismiss = getattr(localMachine, "_dismissLocalBrailleMessage", None)
		except Exception:
			localMachine, dismiss = None, None
		if callable(dismiss):

			def observeDismiss(*args, **kwargs):
				try:
					showing = (
						self._routingTrace is not None
						and self._routingTrace.active()
						and getattr(localMachine, "_showingLocalUiMessage", False) is True
					)
				except Exception:
					showing = False
				if showing:
					self._traceRouting("remote_dismiss_called")
				result = dismiss(*args, **kwargs)
				if showing:
					self._traceRouting("remote_dismiss_returned")
				return result

			try:
				localMachine._dismissLocalBrailleMessage = observeDismiss
			except Exception:
				pass
			else:
				self._dismissObservation = (localMachine, dismiss, observeDismiss)

		def setReceivingBraille(state):
			if self._negotiated and getattr(client, "leaderTransport", None) is self._transport:
				localMachine = getattr(client, "localMachine", None)
				if localMachine is not None:
					self._controlGeneration += 1
					self._traceRouting("control_changed")
					if state:
						self._installSemanticBrailleInput()
						# A capability ACK doubles as a safe refresh request on Linux.
						# This is needed when the session stayed connected while the
						# user temporarily returned to local Windows control.
						with contextlib.suppress(Exception):
							self._transport.send(
								type="lrd_a11y_capability",
								version=NATIVE_BRAILLE_VERSION,
								presentation="nvda",
								message_version=MESSAGE_VERSION,
							)
						queueHandler.queueFunction(
							queueHandler.eventQueue,
							self._replayFocusOnMainThread,
							self._session,
						)
					else:
						# Local Windows focus can replace every remote region. The
						# next remote presentation must rebuild them, even for the
						# same node, rather than asking NVDA to update a missing region.
						self._focusId = None
						self._lastNode = None
						self._removeSemanticBrailleInput(restoreStock=False)
					localMachine.receivingBraille = False
					return
			return original(state)

		client.setReceivingBraille = setReceivingBraille

	def _replayFocusOnMainThread(self, session: int) -> None:
		if not self._isCurrentSession(session):
			return
		# A newer snapshot might already have rebuilt the remote buffer while
		# this callback was queued. Never overwrite it with an earlier focus.
		if self._lastFocus is not None and not self._hasRemoteFocusRegion(self._lastFocus.focusId):
			self._presentOnMainThread(session, self._lastFocus)

	def _recoverFocusBeforeGesture(self, session: int, generation: int, observeRouting=False) -> None:
		if (
			not self._isCurrentSession(session)
			or generation != self._controlGeneration
			or (self._client is not None and not getattr(self._client, "sendingKeys", False))
		):
			return
		self._replayFocusOnMainThread(session)
		handler = braille.handler
		if observeRouting:
			self._routingObserver.install(handler)
		if (
			handler is None
			or self._lastFocus is None
			or getattr(handler, "buffer", None) is not getattr(handler, "mainBuffer", None)
			or not self._hasRemoteFocusRegion(self._lastFocus.focusId)
		):
			return
		# handleUpdate defers TextInfoRegion.update until NVDA's idle pass.
		# A same-ID snapshot has already rebound region.obj and invalidated its
		# old TextInfo sender. Refresh that cached reading range before the
		# queued coordinate script runs, retaining the normal window handling.
		refresh = getattr(handler, "_handlePendingUpdate", None)
		if callable(refresh):
			refresh()

	def _hasRemoteFocusRegion(self, focusId: str | None) -> bool:
		"""Require the current snapshot, not a retained same-ID/session object."""
		mainBuffer = getattr(braille.handler, "mainBuffer", None)
		for region in getattr(mainBuffer, "regions", ()):
			obj = getattr(region, "obj", None)
			if (
				isinstance(obj, RemoteA11yObject)
				and obj._session == self._session
				and obj._node.nodeId == focusId
				and obj is self._objects.get(focusId)
			):
				return True
		return False

	def _activateNativeBraille(self) -> None:
		client = self._client
		if client is None:
			return
		if getattr(client, "leaderTransport", None) is not self._transport:
			return
		if getattr(client, "sendingKeys", False):
			localMachine = getattr(client, "localMachine", None)
			if localMachine is None:
				return
			try:
				self._installSemanticBrailleInput()
				localMachine.receivingBraille = False
			except Exception:
				log.debugWarning("Could not enable NVDA-native remote braille", exc_info=True)

	def _restoreRawBraille(self) -> None:
		client = self._client
		if client is None:
			return
		if getattr(client, "leaderTransport", None) is not self._transport:
			return
		if getattr(client, "sendingKeys", False):
			localMachine = getattr(client, "localMachine", None)
			if localMachine is None:
				return
			try:
				self._removeSemanticBrailleInput(restoreStock=True)
				localMachine.receivingBraille = True
			except Exception:
				log.debugWarning("Could not restore raw Remote Access braille", exc_info=True)

	def _onHello(self, version=None, **_kwargs):
		if self._terminated or version != NATIVE_BRAILLE_VERSION or not self._isCurrentTransport():
			return
		self._session += 1
		self._negotiated = True
		self._clearFocus()
		try:
			self._transport.send(
				type="lrd_a11y_capability",
				version=NATIVE_BRAILLE_VERSION,
				presentation="nvda",
				message_version=MESSAGE_VERSION,
			)
		except Exception:
			self._negotiated = False
			log.error("Failed to acknowledge linux-rdaccess semantic braille")
			return
		self._activateNativeBraille()

	def _onFallback(self, version=None, **_kwargs):
		if self._terminated or version != NATIVE_BRAILLE_VERSION:
			return
		if not self._negotiated:
			return
		self._negotiated = False
		self._clearFocus()
		self._restoreRawBraille()

	def _installMessageHooks(self) -> None:
		hooks = (
			(getattr(braille, "_pre_showBrailleMessage", None), self._onMessageShown),
			(getattr(braille, "_post_dismissBrailleMessage", None), self._onMessageDismissed),
		)
		if not all(
			callable(getattr(event, "register", None)) and callable(getattr(event, "unregister", None))
			for event, _callback in hooks
		):
			return
		try:
			for event, callback in hooks:
				event.register(callback)
				self._messageHooks.append((event, callback))
		except Exception:
			self._removeMessageHooks()
			log.warning("Semantic braille message lifecycle hooks unavailable")

	def _removeMessageHooks(self) -> None:
		self._messageOwner = None
		for event, callback in self._messageHooks:
			with contextlib.suppress(Exception):
				event.unregister(callback)
		self._messageHooks.clear()

	def _onMessageShown(self, **_kwargs) -> None:
		# A later Windows/NVDA message owns its own dismissal and restoration.
		self._messageOwner = None

	def _onMessageDismissed(self, **_kwargs) -> None:
		self._traceRouting("message_dismissed")
		if self._routingObserver.inRoute():
			self._traceOutcome("message_dismissed")
		owner = self._messageOwner
		self._messageOwner = None
		if owner is None:
			return
		handler, session, generation = owner
		if (
			handler is not braille.handler
			or not self._isCurrentSession(session)
			or generation != self._controlGeneration
			or (self._client is not None and not getattr(self._client, "sendingKeys", False))
			or getattr(handler, "buffer", None) is not getattr(handler, "mainBuffer", None)
		):
			return
		self._replayFocusOnMainThread(session)

	def _onMessage(self, version=None, text=None, **_kwargs):
		if (
			not self._isCurrentSession(self._session)
			or type(version) is not int
			or version != MESSAGE_VERSION
		):
			return
		if self._client is not None and not getattr(self._client, "sendingKeys", False):
			return
		cleanText = _sanitizeMessage(text)
		if cleanText is None:
			return
		queueHandler.queueFunction(
			queueHandler.eventQueue,
			self._presentMessageOnMainThread,
			self._session,
			self._controlGeneration,
			cleanText,
		)

	def _presentMessageOnMainThread(self, session: int, generation: int, text: str) -> None:
		if not self._isCurrentSession(session) or generation != self._controlGeneration:
			return
		if self._client is not None and not getattr(self._client, "sendingKeys", False):
			return
		handler = braille.handler
		if handler is not None and callable(getattr(handler, "message", None)):
			messageBuffer = getattr(handler, "messageBuffer", None)
			beforeRegions = tuple(getattr(messageBuffer, "regions", ()))
			handler.message(text)
			afterRegions = tuple(getattr(messageBuffer, "regions", ()))
			shown = len(beforeRegions) != len(afterRegions) or any(
				before is not after for before, after in zip(beforeRegions, afterRegions)
			)
			if (
				messageBuffer is not None
				and afterRegions
				and shown
				and getattr(handler, "buffer", None) is messageBuffer
				and handler is braille.handler
				and self._isCurrentSession(session)
				and generation == self._controlGeneration
				and (self._client is None or getattr(self._client, "sendingKeys", False))
			):
				self._messageOwner = (handler, session, generation)
				self._traceRouting("message_shown")
				# Native message dismissal restores mainBuffer. Repair any local
				# Windows replacement underneath the visible Linux message first.
				# Doing this after message() also respects disabled/speech-only mode.
				self._replayFocusOnMainThread(session)

	def _onFocus(self, version=None, focus_id=None, objects=None, **_kwargs):
		if self._terminated or not self._negotiated or version != NATIVE_BRAILLE_VERSION:
			return
		try:
			message = a11y.decodeMessage(
				{
					"type": "a11y_focus",
					"focus_id": focus_id,
					"objects": objects,
				},
			)
		except (TypeError, ValueError):
			log.debugWarning("Ignoring invalid linux-rdaccess semantic braille snapshot")
			return
		session = self._session
		if self._focusReceiptLoggedSession != session:
			self._focusReceiptLoggedSession = session
			log.info("Semantic braille focus snapshot accepted")
		queueHandler.queueFunction(
			queueHandler.eventQueue,
			self._presentOnMainThread,
			session,
			message,
		)

	def _remoteFocusContextRegions(self, focus, oldFocusRegions=None):
		"""Build context from Linux ancestry without reusing Windows regions."""
		assert config.conf is not None
		ancestors = []
		parent = focus.parent
		while isinstance(parent, RemoteA11yObject):
			ancestors.append(parent)
			parent = parent.parent
		oldContexts = {
			getattr(region, "_focusAncestorIndex", None): region.obj
			for region in oldFocusRegions or ()
			if isinstance(getattr(region, "obj", None), RemoteA11yObject)
		}
		contextChanged = False
		hardLeftSet = False
		for index, parent in enumerate(reversed(ancestors), 1):
			if not parent.isPresentableFocusAncestor:
				continue
			previous = oldContexts.get(index)
			if (
				previous is None
				or not parent._isEqual(previous)
				or any(
					getattr(parent, prop) != getattr(previous, prop)
					for prop in ("name", "role", "roleText", "states", "value", "description")
				)
			):
				contextChanged = True
			region = braille.NVDAObjectRegion(parent, appendText=braille.TEXT_SEPARATOR)
			region._focusAncestorIndex = index
			if (
				contextChanged
				and not hardLeftSet
				and config.conf["braille"]["focusContextPresentation"] == braille.CONTEXTPRES_CHANGEDCONTEXT
			):
				region.focusToHardLeft = True
				hardLeftSet = True
			region.update()
			yield region

	def _focusContextSignature(self, focus):
		context = []
		parent = getattr(focus, "parent", None)
		while isinstance(parent, RemoteA11yObject):
			context.append(
				(
					parent._node.nodeId,
					parent.name,
					parent.role,
					parent.roleText,
					parent.states,
					parent.value,
					parent.description,
				)
			)
			parent = parent.parent
		return context

	def _handleRemoteGainFocus(self, handler, focus) -> None:
		# Core reads its context getter from the handleGainFocus function's
		# globals, while replacements such as BrailleExtender call the braille
		# module export. Scope both lookup paths to this synchronous call and
		# this remote object; leave the replacement handler and local focus intact.
		implementation = inspect.unwrap(getattr(braille, "BrailleHandler", type(handler)).handleGainFocus)
		originals = []
		for namespace in (getattr(implementation, "__globals__", {}), vars(braille)):
			original = namespace.get("getFocusContextRegions")
			if callable(original) and not any(previous is namespace for previous, _getter in originals):
				originals.append((namespace, original))
		if not originals:
			handler.handleGainFocus(focus)
			return

		def scopedGetter(original):
			def contextRegions(obj, oldFocusRegions=None):
				if obj is focus:
					return self._remoteFocusContextRegions(focus, oldFocusRegions)
				return original(obj, oldFocusRegions=oldFocusRegions)

			return contextRegions

		try:
			for namespace, original in originals:
				namespace["getFocusContextRegions"] = scopedGetter(original)
			handler.handleGainFocus(focus)
		finally:
			for namespace, original in reversed(originals):
				namespace["getFocusContextRegions"] = original
			# Remote ancestor indexes must never become cached Windows context.
			braille.invalidateCachedFocusAncestors(0)

	def _logFocusPresentation(self, handler, focusId: str) -> None:
		# Only fixed status booleans are logged, never labels, IDs or text.
		with contextlib.suppress(Exception):
			tetherGetter = getattr(handler, "getTether", None)
			state = (
				self._hasRemoteFocusRegion(focusId),
				bool(getattr(handler, "enabled", False)),
				bool(callable(tetherGetter) and tetherGetter() == "focus"),
			)
			if state != self._focusPresentationState:
				self._focusPresentationState = state
				log.info(
					"Semantic braille presentation state: remote focus present=%s, "
					"enabled=%s, focus tether=%s",
					*state,
				)

	def _presentOnMainThread(self, session: int, message: a11y.FocusMessage) -> None:
		if not self._isCurrentSession(session):
			return

		nodes = {node.nodeId: node for node in message.objects}
		objects: dict[str, RemoteA11yObject] = {}
		controlGeneration = self._controlGeneration

		def canSendInput():
			# NVDA TextInfo and queued braille scripts can retain an old object
			# after its region is rebound. Never reinterpret its coordinates or
			# action index against a newer snapshot or control activation.
			return (
				self._objects is objects
				and controlGeneration == self._controlGeneration
				and self._isCurrentSession(session)
				and (self._client is None or getattr(self._client, "sendingKeys", False))
			)

		def sendAction(objectId, actionIndex):
			if canSendInput():
				self._sendAction(objectId, actionIndex)

		def sendCaret(objectId, offset):
			if canSendInput():
				self._sendCaret(objectId, offset)
			else:
				self._traceOutcome("caret_rejected", offset=offset)

		def buildObject(nodeId: str) -> RemoteA11yObject:
			existing = objects.get(nodeId)
			if existing is not None:
				return existing
			node = nodes[nodeId]
			parent = None if node.parentId is None else buildObject(node.parentId)
			obj = RemoteA11yObject(
				routingObserver=self._traceOutcome,
				processID=0,
				node=node,
				parentObject=parent,
				objectMap=objects,
				actionSender=sendAction,
				caretSender=sendCaret,
				session=session,
			)
			objects[nodeId] = obj
			return obj

		try:
			focus = buildObject(message.focusId)
			for nodeId in nodes:
				buildObject(nodeId)
		except (KeyError, RecursionError):
			log.debugWarning("Ignoring invalid semantic braille ancestry", exc_info=True)
			return

		# Keep only the latest valid snapshot, including changes received while
		# control is local. Temporary messages are never cached or replayed.
		if focus._node.caretOffset is not None and (
			self._lastNode is None
			or self._lastNode.caretOffset != focus._node.caretOffset
			or self._focusId != message.focusId
		):
			self._traceRouting(
				"caret_received",
				offset=focus._node.caretOffset,
				sameFocus=self._focusId == message.focusId,
			)
		self._lastFocus = message
		if self._client is not None and not getattr(self._client, "sendingKeys", False):
			return
		handler = braille.handler
		if handler is None:
			return

		previousFocusId = self._focusId
		previousNode = self._lastNode
		previousFocus = self._objects.get(previousFocusId)
		needsGainFocus = (
			previousFocusId != message.focusId
			or not self._hasRemoteFocusRegion(message.focusId)
			or self._focusContextSignature(previousFocus) != self._focusContextSignature(focus)
		)
		if previousFocusId == message.focusId and not needsGainFocus:
			# NVDA's handleUpdate finds an existing region by object equality but
			# updates region.obj, not the new object argument. Rebind semantic
			# regions to this snapshot so names, values, text and caret state do
			# not remain one snapshot behind while preserving the braille window.
			mainBuffer = getattr(handler, "mainBuffer", None)
			for region in getattr(mainBuffer, "regions", ()):
				oldObj = getattr(region, "obj", None)
				if not isinstance(oldObj, RemoteA11yObject) or oldObj._session != session:
					continue
				newObj = objects.get(oldObj._node.nodeId)
				if newObj is not None:
					region.obj = newObj
		self._objects = objects
		self._focusId = message.focusId
		self._lastNode = focus._node

		if needsGainFocus:
			self._handleRemoteGainFocus(handler, focus)
			self._logFocusPresentation(handler, message.focusId)
			return

		caretChanged = previousNode is not None and (
			previousNode.text != focus._node.text
			or previousNode.caretOffset != focus._node.caretOffset
			or previousNode.selectionStart != focus._node.selectionStart
			or previousNode.selectionEnd != focus._node.selectionEnd
		)
		if caretChanged and callable(getattr(handler, "handleCaretMove", None)):
			handler.handleCaretMove(focus)
		else:
			handler.handleUpdate(focus)

	def _sendAction(self, objectId: str, actionIndex: int) -> None:
		if self._terminated or not self._negotiated:
			return
		try:
			self._transport.send(
				type="lrd_a11y_action",
				version=NATIVE_BRAILLE_VERSION,
				object_id=objectId,
				action_index=actionIndex,
			)
		except Exception:
			log.error("Failed to send linux-rdaccess semantic action")

	def _sendCaret(self, objectId: str, offset: int) -> None:
		if self._terminated or not self._negotiated:
			return
		if type(offset) is not int or not 0 <= offset <= 8192:
			return
		try:
			self._transport.send(
				type="lrd_a11y_caret",
				version=NATIVE_BRAILLE_VERSION,
				object_id=objectId,
				offset=offset,
			)
			self._traceRouting("caret_sent", offset=offset, sameFocus=objectId == self._focusId)
			self._traceOutcome("caret_send_returned", offset=offset, sameFocus=objectId == self._focusId)
		except Exception:
			self._traceOutcome("caret_send_failed", offset=offset, sameFocus=objectId == self._focusId)
			log.error("Failed to send linux-rdaccess semantic caret")

	def terminate(self) -> None:
		if self._terminated:
			return
		self._routingObserver.close()
		if self._dismissObservation is not None:
			machine, original, installed = self._dismissObservation
			with contextlib.suppress(Exception):
				if getattr(machine, "_dismissLocalBrailleMessage", None) is installed:
					machine._dismissLocalBrailleMessage = original
			self._dismissObservation = None
		self._routingTrace = None
		self._removeMessageHooks()
		self._restoreRawBraille()
		self._removeSemanticBrailleInput(restoreStock=False)
		self._terminated = True
		self._negotiated = False
		self._clearFocus()
		for event in self._transportEvents:
			with contextlib.suppress(Exception):
				event.unregister(self._onTransportDisconnected)
		self._transportEvents.clear()

		if self._client is not None and self._originalSetReceivingBraille is not None:
			try:
				if (
					getattr(self._client, "setReceivingBraille", None)
					is not self._originalSetReceivingBraille
				):
					self._client.setReceivingBraille = self._originalSetReceivingBraille
			except Exception:
				pass

		if self._installedParse is not None:
			try:
				if getattr(self._transport, "parse", None) is self._installedParse:
					self._transport.parse = self._originalParse
			except Exception:
				pass

		unregister = getattr(self._manager, "unregister_callback", None)
		if callable(unregister):
			for name, callback in (
				(_HELLO_CALLBACK, self._onHello),
				(_FOCUS_CALLBACK, self._onFocus),
				(_MESSAGE_CALLBACK, self._onMessage),
				(_FALLBACK_CALLBACK, self._onFallback),
			):
				with contextlib.suppress(Exception):
					unregister(name, callback)


def _candidateTransports(plugin) -> typing.Iterator[object]:
	"""Yield likely legacy NVDA Remote/TeleNVDA transports."""
	seen: set[int] = set()
	queue = [plugin]
	attrs = ("remoteClient", "client", "transport", "localMachine", "remoteMachine")
	for _depth in range(3):
		nextQueue = []
		for obj in queue:
			if obj is None or id(obj) in seen:
				continue
			seen.add(id(obj))
			manager = getattr(obj, "callback_manager", None)
			if (
				manager is not None
				and callable(getattr(manager, "register_callback", None))
				and callable(getattr(obj, "send", None))
			):
				yield obj
			for attr in attrs:
				try:
					value = getattr(obj, attr, None)
				except Exception:
					continue
				if value is not None:
					nextQueue.append(value)
		queue = nextQueue


def findRemoteAccessTransport(runningPlugins=()) -> object | None:
	"""Find built-in NVDA Remote Access first, then legacy/TeleNVDA transports."""
	_client, transport = _builtinRemoteState()
	if transport is not None and callable(getattr(transport, "send", None)):
		return transport

	for plugin in runningPlugins:
		module = plugin.__class__.__module__.lower()
		if "remoteclient" not in module and "telenvda" not in module:
			continue
		for transport in _candidateTransports(plugin):
			return transport
	return None
