"""Pure-Python AT-SPI object snapshot model for the remote NVDA object channel."""

from __future__ import annotations

from typing import Any, Callable

A11Y_FOCUS_EVENTS = frozenset({
    "object:state-changed:focused",
    "object:active-descendant-changed",
    "window:activate",
})
A11Y_TEXT_EVENTS = frozenset({
    "object:text-caret-moved",
    "object:text-selection-changed",
    "object:text-changed:insert",
    "object:text-changed:delete",
})
DEFAULT_MAX_OBJECTS = 64
MAX_FOCUS_SEARCH_NODES = 4096
MAX_FOCUS_SEARCH_DEPTH = 32
# Each child costs a synchronous D-Bus round trip on the GLib main loop, so one
# enumeration is bounded no matter how many items a list, tree or document has.
MAX_CHILDREN = 128
MAX_ACTIONS = 32
MAX_FOCUS_TEXT_CHARS = 8192
MAX_NAME_CHARS = 4096
MAX_DESCRIPTION_CHARS = 8192
MAX_VALUE_CHARS = 8192
MAX_ROLE_CHARS = 128
MAX_STATE_CHARS = 64
MAX_STATES = 64
MAX_ACTION_NAME_CHARS = 256


def _clean(value: Any, limit: int | None = None) -> str:
    text = " ".join(str("" if value is None else value).split())
    return text if limit is None else text[:limit]


def _invoke(obj, names: tuple[str, ...], *args):
    for name in names:
        method = getattr(obj, name, None)
        if not callable(method):
            continue
        try:
            return method(*args)
        except Exception:
            continue
    return None


def _looks_accessible(obj) -> bool:
    return obj is not None and (
        callable(getattr(obj, "get_name", None))
        or callable(getattr(obj, "getName", None))
        or hasattr(obj, "name")
    )


def _name(obj) -> str:
    value = _invoke(obj, ("get_name", "getName"))
    if value is None:
        value = getattr(obj, "name", "")
    return _clean(value, MAX_NAME_CHARS)


def _role_name(obj) -> str:
    value = _invoke(obj, ("get_role_name", "getRoleName"))
    if value is None:
        value = getattr(obj, "roleName", "")
    return _clean(value, MAX_ROLE_CHARS)


def _description(obj) -> str:
    value = _invoke(obj, ("get_description", "getDescription"))
    if value is None:
        value = getattr(obj, "description", "")
    return _clean(value, MAX_DESCRIPTION_CHARS)


def object_id(obj: object) -> str:
    """Return a stable ID for one live AT-SPI proxy within this bridge process."""
    try:
        value = hash(obj)
    except TypeError:
        value = id(obj)
    return f"{value & ((1 << 64) - 1):016x}"


def _parent(obj):
    parent = _invoke(obj, ("get_parent", "getParent"))
    if parent is not None:
        return parent
    try:
        return getattr(obj, "parent", None)
    except Exception:
        return None


def _children_info(obj, *, limit: int = MAX_CHILDREN, around=None) -> tuple[list, bool]:
    """Return at most `limit` children and whether enumeration is incomplete.

    When the object has more children than `limit`, the window is centred on
    `around` (a child, normally the one on the path to the focus) so the focused
    item's neighbours are the ones returned, not the first items of the list.
    """
    count = _invoke(obj, ("get_child_count", "getChildCount"))
    if count is None:
        count = getattr(obj, "childCount", None)
    try:
        count = int(count)
    except (TypeError, ValueError):
        # A failed provider query is not evidence of an empty subtree. Focus
        # resync must keep its cache when the live tree cannot be inspected.
        return [], True
    count = max(0, count)
    limit = max(1, limit)
    truncated = count > limit
    start = 0
    if truncated and around is not None:
        index = _invoke(around, ("get_index_in_parent", "getIndexInParent"))
        try:
            index = int(index)
        except (TypeError, ValueError):
            index = -1
        if 0 <= index < count:
            start = min(max(0, index - limit // 2), count - limit)
    children = []
    for index in range(start, min(count, start + limit)):
        child = _invoke(obj, ("get_child_at_index", "getChildAtIndex"), index)
        if _looks_accessible(child):
            children.append(child)
        else:
            truncated = True
    if truncated and around is not None and object_id(around) not in {object_id(c) for c in children}:
        # No usable index in parent: never lose the child the caller needs.
        children = [around] + children[: limit - 1]
    return children, truncated


def _children(obj, *, limit: int = MAX_CHILDREN, around=None) -> list:
    return _children_info(obj, limit=limit, around=around)[0]


def _nearest_first(children: list, anchor) -> list:
    """Order siblings by distance from `anchor` (ties keep document order)."""
    anchor_id = object_id(anchor)
    for position, child in enumerate(children):
        if object_id(child) == anchor_id:
            order = sorted(range(len(children)), key=lambda i: abs(i - position))
            return [children[i] for i in order]
    return children


def _state_name(state: object) -> str:
    """Normalize GI or legacy pyatspi state tokens into wire-format spelling."""
    for attr in ("value_nick", "value_name", "name"):
        raw = getattr(state, attr, None)
        if raw:
            text = str(raw)
            break
    else:
        text = str(state)

    # Legacy pyatspi commonly exposes integer STATE_* constants. Resolve them
    # lazily so this pure-Python module still imports where pyatspi is absent.
    if text.strip().lstrip("-").isdigit():
        try:
            import pyatspi  # type: ignore
            for attr in dir(pyatspi):
                if attr.startswith("STATE_") and getattr(pyatspi, attr, object()) == state:
                    text = attr
                    break
        except Exception:
            pass

    text = text.strip().lower()
    for prefix in ("atspi_state_", "state_"):
        if text.startswith(prefix):
            text = text[len(prefix) :]
            break
    return text.replace("-", " ").replace("_", " ")


def _states(obj, *, focused: bool, query_complete: list[bool] | None = None) -> list[str]:
    states: set[str] = set()
    state_set = _invoke(obj, ("get_state_set", "getState"))
    if state_set is None:
        raw_states = ()
        if query_complete is not None:
            query_complete[0] = False
    else:
        raw_states = _invoke(state_set, ("get_states", "getStates"))
        if raw_states is None:
            raw_states = getattr(state_set, "states", None)
            if raw_states is None and query_complete is not None:
                query_complete[0] = False
    for state in raw_states or ():
        name = _state_name(state)[:MAX_STATE_CHARS]
        if name and name != "invalid":
            states.add(name)
            if len(states) >= MAX_STATES:
                break
    # The event itself is authoritative for the focus target and covers
    # toolkits that lag when their state set is queried during notification.
    if focused:
        states.add("focused")
    return sorted(states)


def _action_iface(obj):
    return _invoke(obj, ("get_action_iface", "get_action", "queryAction"))


def action_names(obj) -> list[str]:
    """Return the bounded ordered AT-SPI action names for an accessible object."""
    iface = _action_iface(obj)
    if iface is None:
        return []
    count = _invoke(iface, ("get_n_actions", "getNActions"))
    if count is None:
        count = getattr(iface, "nActions", None)
    try:
        count = min(MAX_ACTIONS, max(0, int(count)))
    except (TypeError, ValueError):
        return []
    names = []
    for index in range(count):
        try:
            name = _clean(_invoke(iface, ("get_action_name", "getName"), index))
        except Exception:
            name = ""
        names.append((name or f"action {index + 1}")[:MAX_ACTION_NAME_CHARS])
    return names


def perform_action(obj, index: int) -> bool:
    """Perform one bounded AT-SPI action by index."""
    if type(index) is not int or index < 0 or index >= MAX_ACTIONS:
        return False
    iface = _action_iface(obj)
    if iface is None:
        return False
    count = _invoke(iface, ("get_n_actions", "getNActions"))
    if count is None:
        count = getattr(iface, "nActions", None)
    try:
        count = int(count)
    except (TypeError, ValueError):
        return False
    if index >= count:
        return False
    for name in ("do_action", "doAction"):
        method = getattr(iface, name, None)
        if not callable(method):
            continue
        try:
            return method(index) is not False
        except Exception:
            # The provider may have acted before its reply failed. Retrying a
            # different spelling of the same operation can activate it twice.
            return False
    return False


def _gi_atspi_method(iface, interface_name: str, method_name: str, *args):
    """Call an AT-SPI interface explicitly when GI Accessible aliases shadow it.

    Newer libatspi versions expose Accessible.get_text/get_selection aliases
    with different signatures. Do not use those aliases for Text/Value methods.
    None means this is not a real GI Accessible, so use pyatspi/fake dispatch.
    """
    try:
        from gi.repository import Atspi
    except (ImportError, ValueError):
        return None
    if not isinstance(iface, Atspi.Accessible):
        return None
    # Some libatspi releases do not expose every interface function.
    # A provider can also fail one interface query while its other properties
    # remain usable. Match _invoke's fallback behavior so a missing selection
    # or Value description cannot discard the entire focus snapshot.
    interface = getattr(Atspi, interface_name, None)
    method = getattr(interface, method_name, None)
    if not callable(method):
        return None
    try:
        return method(iface, *args)
    except Exception:
        return None


def _text_iface(obj):
    return _invoke(obj, ("get_text_iface", "queryText"))


def _report_caret_diagnostic(diagnostic, value: str) -> None:
    """Optional diagnostics must not become a dependency of native caret writes."""
    if diagnostic is None:
        return
    try:
        if __package__:
            from ..caret_diagnostics import CaretReason, report_caret_reason
        else:
            from linux_rdaccess_caret_diagnostics import (
                CaretReason,
                report_caret_reason,
            )
        report_caret_reason(diagnostic, CaretReason(value))
    except Exception:
        pass


def set_caret_offset(obj, offset: int, *, before_action: Callable[[], Any] | None = None,
                     diagnostic=None) -> bool:
    """Move one current semantic text object's caret to a bounded character offset."""
    def rejected(reason):
        _report_caret_diagnostic(diagnostic, reason)
        return False

    if type(offset) is not int or offset < 0 or offset > MAX_FOCUS_TEXT_CHARS:
        return rejected("invalid_offset")
    iface = _text_iface(obj)
    if iface is None:
        return rejected("text_interface_unavailable")
    character_count = _invoke(iface, ("get_character_count", "getCharacterCount"))
    if character_count is None:
        character_count = getattr(iface, "characterCount", None)
    try:
        character_count = int(character_count)
    except (TypeError, ValueError):
        return rejected("character_count_unavailable")
    if character_count < 0 or offset > character_count:
        return rejected("offset_out_of_range")
    for name in ("set_caret_offset", "setCaretOffset"):
        method = getattr(iface, name, None)
        if not callable(method):
            continue
        try:
            if before_action is not None:
                before_action()
        except Exception:
            return rejected("before_route_error")
        try:
            accepted = method(offset) is not False
        except Exception:
            return rejected("provider_error")
        _report_caret_diagnostic(diagnostic, "setter_returned" if accepted else "provider_refused")
        return accepted
    descriptor = getattr(type(iface), "caretOffset", None)
    if not isinstance(descriptor, property) or descriptor.fset is None:
        return rejected("setter_unavailable")
    try:
        if before_action is not None:
            before_action()
    except Exception:
        return rejected("before_route_error")
    try:
        iface.caretOffset = offset
    except Exception:
        return rejected("provider_error")
    _report_caret_diagnostic(diagnostic, "setter_returned")
    return True


def _selection_offsets(iface) -> tuple[int, int] | None:
    count = _invoke(iface, ("get_n_selections", "getNSelections"))
    if count is None:
        count = getattr(iface, "nSelections", None)
    try:
        if int(count) <= 0:
            return None
    except (TypeError, ValueError):
        return None
    selection = _gi_atspi_method(iface, "Text", "get_selection", 0)
    if selection is None:
        selection = _invoke(iface, ("get_selection", "getSelection"), 0)
    if selection is None:
        return None

    start = getattr(selection, "start_offset", None)
    end = getattr(selection, "end_offset", None)
    if start is None or end is None:
        if isinstance(selection, tuple) and len(selection) >= 2:
            start, end = selection[-2], selection[-1]
        else:
            return None
    try:
        start, end = int(start), int(end)
    except (TypeError, ValueError):
        return None
    if start < 0 or end < start:
        return None
    return start, end


def caret_beyond_text_window(obj) -> bool:
    """Whether a text object's real caret lies past the bounded snapshot window.

    _text_snapshot() carries only the first MAX_FOCUS_TEXT_CHARS characters, so a
    caret beyond them is reported as None. A snapshot of the document start without
    a caret would not follow the user, so callers can use this to tell that case
    apart from text that simply has no caret.
    """
    iface = _text_iface(obj)
    if iface is None:
        return False
    character_count = _invoke(iface, ("get_character_count", "getCharacterCount"))
    if character_count is None:
        character_count = getattr(iface, "characterCount", None)
    try:
        if int(character_count) <= MAX_FOCUS_TEXT_CHARS:
            return False
        raw_caret = _invoke(iface, ("get_caret_offset", "getCaretOffset"))
        if raw_caret is None:
            raw_caret = getattr(iface, "caretOffset", None)
        return int(raw_caret) > MAX_FOCUS_TEXT_CHARS
    except Exception:
        return False


def _text_snapshot(obj, *, focused: bool) -> dict[str, Any]:
    empty = {
        "text_supported": False,
        "text": "",
        "text_truncated": False,
        "caret_offset": None,
        "selection_start": None,
        "selection_end": None,
    }
    if not focused:
        return empty

    iface = _text_iface(obj)
    if iface is None:
        return empty
    character_count = _invoke(iface, ("get_character_count", "getCharacterCount"))
    if character_count is None:
        character_count = getattr(iface, "characterCount", None)
    try:
        character_count = max(0, int(character_count))
    except (TypeError, ValueError):
        return empty

    end = min(character_count, MAX_FOCUS_TEXT_CHARS)
    try:
        raw_text = _gi_atspi_method(iface, "Text", "get_text", 0, end)
        if raw_text is None:
            raw_text = _invoke(iface, ("get_text", "getText"), 0, end)
        text = str(raw_text or "")
    except Exception:
        return empty
    # Guard against a broken provider returning more text than requested.
    text = text[:MAX_FOCUS_TEXT_CHARS]
    visible_length = len(text)

    try:
        raw_caret = _invoke(iface, ("get_caret_offset", "getCaretOffset"))
        if raw_caret is None:
            raw_caret = getattr(iface, "caretOffset", None)
        caret = int(raw_caret)
    except Exception:
        caret = None
    if caret is not None and not 0 <= caret <= visible_length:
        caret = None

    selection_start = selection_end = None
    selection = _selection_offsets(iface)
    if selection is not None:
        start, finish = selection
        if 0 <= start <= finish <= visible_length:
            selection_start, selection_end = start, finish

    return {
        "text_supported": True,
        "text": text,
        "text_truncated": character_count > visible_length,
        "caret_offset": caret,
        "selection_start": selection_start,
        "selection_end": selection_end,
    }


def _value(obj) -> str:
    """Return the human-readable GI or pyatspi Value text/current value."""
    iface = _invoke(obj, ("get_value_iface", "get_value", "queryValue"))
    if iface is None:
        return ""

    # GI Accessible.get_text is a Text alias, not a Value description.
    # Never call it without offsets for a real GI Value interface.
    try:
        from gi.repository import Atspi
        is_gi_accessible = isinstance(iface, Atspi.Accessible)
    except (ImportError, ValueError):
        is_gi_accessible = False
    if is_gi_accessible:
        # Use Value.get_text explicitly: Accessible.get_text is a different
        # interface accessor in libatspi 2.50+.
        raw_text = _gi_atspi_method(iface, "Value", "get_text")
    else:
        raw_text = _invoke(iface, ("get_text", "getText"))
    # A provider can return an interface object instead of a textual value.
    text = _clean(raw_text, MAX_VALUE_CHARS) if isinstance(raw_text, str) else ""
    if text:
        return text

    current = _gi_atspi_method(iface, "Value", "get_current_value")
    if current is None:
        current = _invoke(iface, ("get_current_value", "getCurrentValue"))
    if current is None:
        current = getattr(iface, "currentValue", None)
    if current is None:
        return ""
    if isinstance(current, float) and current.is_integer():
        return str(int(current))
    return _clean(current, MAX_VALUE_CHARS)


def _bounds(obj, coord_type) -> list[int] | None:
    if coord_type is None:
        return None
    try:
        component = obj.get_component_iface()
    except Exception:
        component = None
    if component is None:
        try:
            component = obj.get_component()
        except Exception:
            return None
    try:
        rect = component.get_extents(coord_type)
        values = [int(rect.x), int(rect.y), int(rect.width), int(rect.height)]
    except Exception:
        return None
    if values[2] < 0 or values[3] < 0:
        return None
    return values


def find_focused_object_ex(
    desktop,
    *,
    max_nodes: int = MAX_FOCUS_SEARCH_NODES,
    max_depth: int = MAX_FOCUS_SEARCH_DEPTH,
):
    """Find the focused AT-SPI object; return ``(object_or_None, complete)``.

    ``complete`` is False when the node budget, the depth limit or a child cap
    cut the walk short.  ``(None, True)`` therefore means "nothing is focused",
    while ``(None, False)`` means "not found within the bounds": callers must not
    treat the latter as a loss of focus.
    """
    budget = [max(1, max_nodes)]
    complete = [True]

    def has_state(obj, wanted: str) -> bool:
        return wanted in _states(obj, focused=False, query_complete=complete)

    def kids(obj):
        children, truncated = _children_info(obj)
        if truncated:
            complete[0] = False
        return children

    def search(obj, depth: int):
        if budget[0] <= 0 or depth > max_depth:
            complete[0] = False
            return None
        budget[0] -= 1
        candidate = obj if has_state(obj, "focused") else None
        for child in kids(obj):
            found = search(child, depth + 1)
            if found is not None:
                return found
        # Some toolkits mark a container as focused alongside its actual
        # keyboard target. Keep the container only if no descendant is focused.
        return candidate

    windows = []
    for application in kids(desktop):
        windows.extend(kids(application))
    active = [window for window in windows if has_state(window, "active")]
    for group in (active, [w for w in windows if w not in active]):
        fallback = None
        for window in group:
            found = search(window, 0)
            if found is not None:
                if object_id(found) != object_id(window):
                    return found, True
                # XFWM exposes an active, focused top-level window of its own.
                # Prefer the focused control in another active application;
                # inactive windows still remain below this group's fallback.
                if fallback is None:
                    fallback = found
        if fallback is not None:
            return fallback, True
    return None, complete[0]


def find_focused_object(
    desktop,
    *,
    max_nodes: int = MAX_FOCUS_SEARCH_NODES,
    max_depth: int = MAX_FOCUS_SEARCH_DEPTH,
):
    """Find the AT-SPI object that currently has keyboard focus, or None.

    Used when no focus event is available to react to: the bridge started
    after the desktop took focus, or a channel (re)connected later than the last
    focus change.  Windows in the "active" state are searched first; the walk is
    bounded in nodes, depth and children per node so a huge tree cannot stall the
    GLib main loop.  See find_focused_object_ex() to tell "nothing focused" from
    "search limit reached".
    """
    return find_focused_object_ex(desktop, max_nodes=max_nodes, max_depth=max_depth)[0]


def _snapshot(
    obj,
    *,
    parent_id: str | None,
    child_ids: list[str],
    focused: bool,
    coord_type=None,
) -> dict[str, Any]:
    description = _description(obj)
    text_snapshot = _text_snapshot(obj, focused=focused)
    return {
        "id": object_id(obj),
        "parent_id": parent_id,
        "child_ids": child_ids,
        "name": _name(obj),
        "role": _role_name(obj),
        "description": description,
        "value": _value(obj),
        "actions": action_names(obj),
        **text_snapshot,
        "states": _states(obj, focused=focused),
        "bounds": _bounds(obj, coord_type),
    }


def build_text_update(
    event_type: str,
    source,
    *,
    object_registry: dict[str, object],
):
    """Build a focused text/caret update for an object in the current snapshot."""
    if event_type not in A11Y_TEXT_EVENTS or not _looks_accessible(source):
        return None
    oid = object_id(source)
    if oid not in object_registry:
        return None
    snapshot = _text_snapshot(source, focused=True)
    if not snapshot["text_supported"]:
        return None
    return {
        "object_id": oid,
        "event": "caret" if event_type in {
            "object:text-caret-moved",
            "object:text-selection-changed",
        } else "textChange",
        **snapshot,
    }


def build_focus_payload(
    event_type: str,
    detail1: int,
    source,
    any_data=None,
    *,
    max_depth: int = 24,
    max_objects: int = DEFAULT_MAX_OBJECTS,
    coord_type=None,
    object_registry: dict[str, object] | None = None,
):
    """Build a bounded focus-neighborhood snapshot.

    The focused object and its ancestor chain are highest priority. Remaining
    capacity is filled with the immediate children of each object on that path.
    This exposes the focused object's children and its siblings at each ancestor
    level without serializing an application's entire accessibility tree.
    """
    if event_type not in A11Y_FOCUS_EVENTS:
        return None
    if event_type == "object:state-changed:focused" and not detail1:
        return None
    target = any_data if event_type == "object:active-descendant-changed" and _looks_accessible(any_data) else source
    if not _looks_accessible(target):
        return None
    if max_objects < 1:
        return None

    chain = []
    current = target
    seen = set()
    for _ in range(min(max_depth, max_objects)):
        oid = object_id(current)
        if oid in seen:
            break
        seen.add(oid)
        chain.append(current)
        parent = _parent(current)
        role = _role_name(current)
        if parent is None or role == "application":
            break
        current = parent

    selected = list(chain)
    selected_ids = {object_id(obj) for obj in selected}
    children_cache: dict[str, list] = {}

    # Target first gives its direct children priority; then each ancestor gives
    # us the target's siblings and sibling groups higher in the hierarchy.
    for position, parent in enumerate(chain):
        parent_oid = object_id(parent)
        # Window the children around the chain member below `parent` so a focused
        # item in a very long list keeps its neighbours in the snapshot.
        anchor = chain[position - 1] if position else None
        children = _children(parent, around=anchor)
        children_cache[parent_oid] = children
        candidates = children
        if anchor is not None and len(selected) + len(children) > max_objects:
            # Not everything fits: keep the siblings closest to the focus.
            candidates = _nearest_first(children, anchor)
        for child in candidates:
            if len(selected) >= max_objects:
                break
            child_oid = object_id(child)
            if child_oid in selected_ids:
                continue
            selected.append(child)
            selected_ids.add(child_oid)
        if len(selected) >= max_objects:
            break

    # Only path members can have selected children (selected = path + the path's
    # children), so enumerating any other object's children is wasted D-Bus work.
    # Path members the object cap kept us from enumerating still link to the path
    # member below them.
    for position, member in enumerate(chain):
        children_cache.setdefault(object_id(member), [chain[position - 1]] if position else [])
    for obj in selected:
        children_cache.setdefault(object_id(obj), [])

    focus_id = object_id(target)
    objects = []
    for obj in selected:
        oid = object_id(obj)
        parent = _parent(obj)
        role = _role_name(obj)
        parent_oid = object_id(parent) if parent is not None else None
        parent_id = None if role == "application" or parent_oid not in selected_ids else parent_oid
        child_ids = [
            child_oid
            for child in children_cache[oid]
            if (child_oid := object_id(child)) in selected_ids
        ]
        objects.append(
            _snapshot(
                obj,
                parent_id=parent_id,
                child_ids=child_ids,
                focused=oid == focus_id,
                coord_type=coord_type,
            )
        )

    if object_registry is not None:
        object_registry.clear()
        object_registry.update({object_id(obj): obj for obj in selected})

    return {
        "focus_id": focus_id,
        "objects": objects,
    }
