#!/usr/bin/env python3
"""Install and operate linux-rdaccess as a user-level Linux command."""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

from .connection.remote_access import (
    CUSTOMIZATION_EVENT_API_MARKER,
    CUSTOMIZATION_RECONNECT_MARKER,
    CUSTOMIZATION_SAY_ALL_CALLBACK_MARKER,
    CUSTOMIZATION_SPEECH_SEQUENCE_MARKER,
    DEFAULT_CONFIG,
    LEGACY_COMPAT_MARKER,
    LEGACY_COMPAT_MARKER_V1,
    LEGACY_LOCAL_MACHINE_RELATIVE,
    LEGACY_REMOTE_CONTROLLER_RELATIVE,
    LEGACY_TRANSPORT_RELATIVE,
    LOCAL_MACHINE_MARKER,
    LOCAL_MACHINE_MARKER_V1,
    TRANSPORT_CLEANUP_MARKER,
    TRANSPORT_CLEANUP_MARKER_V1,
    TRANSPORT_CLEANUP_MARKER_V2,
    TRANSPORT_CLEANUP_MARKER_V3,
    TRANSPORT_CLEANUP_MARKER_V4,
    TRANSPORT_CLEANUP_MARKER_V5,
    TRANSPORT_CLEANUP_MARKER_V6,
    TRANSPORT_PENDING_CONNECT_MARKER,
    _legacy_transport_cleanup_v7_current,
    disable_legacy_orca_connection,
    legacy_controller_patch_current,
    legacy_customization_event_api_patch_current,
    legacy_customization_reconnect_patch_current,
    legacy_customization_say_all_callback_patch_current,
    legacy_customization_speech_sequence_patch_current,
    legacy_local_machine_patch_current,
    legacy_transport_cleanup_patch_current,
    load_config,
    print_status,
    update_legacy_orca_customizations,
)
from .installation.files import orca_runtime_sources, source_bundle_root

APP_NAME = "linux-rdaccess"
DEFAULT_ORCA_CONFIG = Path("~/.local/share/orca/orca-customizations.py").expanduser()
DEFAULT_SHARE_DIR = Path("~/.local/share/linux-rdaccess").expanduser()
DEFAULT_BIN = Path("~/.local/bin/linux-rdaccess").expanduser()
DEFAULT_AUTOSTART = Path("~/.config/autostart/linux-rdaccess.desktop").expanduser()
GRAPHICAL_SESSION_PROCESSES = (
    "xfce4-session",
    "gnome-shell",
    "cinnamon",
    "mate-session",
    "lxqt-session",
    "plasmashell",
)


def graphical_session_env(
    *,
    proc_root: Path = Path("/proc"),
    base_env: dict[str, str] | None = None,
    uid: int | None = None,
) -> dict[str, str]:
    env = dict(os.environ if base_env is None else base_env)

    # A DISPLAY alone is not enough to identify the user's real desktop.
    # SSH/X11 forwarding commonly sets DISPLAY while omitting the desktop
    # session bus/runtime directory; restarting Orca in that environment can
    # make accessibility disappear from the active Linux session.
    has_display = bool(env.get("DISPLAY") or env.get("WAYLAND_DISPLAY"))
    has_session_bus = bool(env.get("DBUS_SESSION_BUS_ADDRESS"))
    has_runtime = bool(env.get("XDG_RUNTIME_DIR"))
    forwarded_display = bool(re.fullmatch(
        r"(?:localhost|127\.0\.0\.1|\[::1\]):\d+(?:\.\d+)?", env.get("DISPLAY", "")
    )) and not env.get("WAYLAND_DISPLAY")
    # SSH can inherit the user's systemd bus and runtime directory while
    # forwarding X11 to the client. Those three variables still do not make
    # the forwarded display the local desktop.
    if has_display and has_session_bus and has_runtime and not forwarded_display:
        return env

    target_uid = os.getuid() if uid is None else uid
    wanted = {
        "DISPLAY",
        "WAYLAND_DISPLAY",
        "XAUTHORITY",
        "DBUS_SESSION_BUS_ADDRESS",
        "AT_SPI_BUS_ADDRESS",
        "XDG_RUNTIME_DIR",
        "XDG_SESSION_TYPE",
    }

    # Several sessions of the same user can coexist (an xrdp desktop next to a
    # console login). Directory order is arbitrary, so choose the newest one,
    # as ``pgrep -n`` does in the helper scripts.
    candidates: list[tuple[int, int, dict[str, str]]] = []
    for entry in proc_root.iterdir():
        if not entry.name.isdigit():
            continue
        try:
            comm = (entry / "comm").read_text(encoding="utf-8").strip()
            if comm not in GRAPHICAL_SESSION_PROCESSES:
                continue
            status = (entry / "status").read_text(encoding="utf-8")
            uid_line = next(line for line in status.splitlines() if line.startswith("Uid:"))
            real_uid = int(uid_line.split()[1])
            if real_uid != target_uid:
                continue
            raw = (entry / "environ").read_bytes().split(b"\0")
        except (OSError, StopIteration, ValueError):
            continue

        session_env: dict[str, str] = {}
        for item in raw:
            if not item or b"=" not in item:
                continue
            key_b, value_b = item.split(b"=", 1)
            key = key_b.decode(errors="ignore")
            if key in wanted:
                session_env[key] = value_b.decode(errors="ignore")

        if session_env.get("DISPLAY") or session_env.get("WAYLAND_DISPLAY"):
            candidates.append((_process_start_time(entry), int(entry.name), session_env))

    if candidates:
        # Session variables belong together. In particular, retaining an SSH
        # XAUTHORITY or forwarded DISPLAY when the desktop omits it can point
        # Orca at an unrelated X server instead of the selected desktop.
        for key in wanted:
            env.pop(key, None)
        env.update(max(candidates, key=lambda item: item[:2])[2])
    return env


def _process_start_time(entry: Path) -> int:
    """Start time in clock ticks from /proc/<pid>/stat, or 0 when unavailable."""
    try:
        stat = (entry / "stat").read_text(encoding="utf-8")
        # The command name may contain spaces and parentheses; the fields that
        # follow the last ")" are fixed. starttime is field 22 (index 19 here).
        return int(stat.rsplit(")", 1)[1].split()[19])
    except (OSError, IndexError, ValueError):
        return 0


def restart_orca() -> int:
    """Replace Orca without waiting for the long-lived screen reader to exit."""
    try:
        subprocess.Popen(
            ["orca", "--replace"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            env=graphical_session_env(),
            start_new_session=True,
        )
    except FileNotFoundError:
        print("Orca was not found in PATH.")
        return 1
    except OSError:
        print("Orca could not be started.")
        return 1
    return 0


def install_user_files(
    source_dir: Path,
    *,
    share_dir: Path = DEFAULT_SHARE_DIR,
    bin_path: Path = DEFAULT_BIN,
) -> None:
    """Install the runtime bundle using the internal installation module."""
    from linux_rdaccess_core.installation.files import install_runtime_files

    install_runtime_files(source_dir, share_dir=share_dir, bin_path=bin_path)


def write_autostart(
    *,
    autostart_path: Path = DEFAULT_AUTOSTART,
    bin_path: Path = DEFAULT_BIN,
) -> None:
    from linux_rdaccess_core.installation.autostart import write_autostart_file

    write_autostart_file(autostart_path=autostart_path, bin_path=bin_path)


def remove_autostart(path: Path = DEFAULT_AUTOSTART) -> None:
    from linux_rdaccess_core.installation.autostart import remove_autostart_file

    remove_autostart_file(path)


def connect(
    *,
    config_path: Path,
    orca_config: Path,
    restart: bool = True,
    quiet: bool = False,
) -> int:
    from linux_rdaccess_core.connection.session import connect_session

    return connect_session(
        config_path=config_path, orca_config=orca_config,
        restart=restart, quiet=quiet, load_config=load_config,
        update_customizations=update_legacy_orca_customizations,
        restart_orca=restart_orca,
    )


def disconnect(*, orca_config: Path, restart: bool = True, quiet: bool = False) -> int:
    from linux_rdaccess_core.connection.session import disconnect_session

    return disconnect_session(
        orca_config=orca_config, restart=restart, quiet=quiet,
        disable_connection=disable_legacy_orca_connection,
        restart_orca=restart_orca,
    )


DEFAULT_VSCODE_SETTINGS = Path("~/.config/Code/User/settings.json").expanduser()


def _strip_jsonc(text: str) -> str:
    """Remove // and /* */ comments and trailing commas (VS Code uses JSONC)."""
    out: list[str] = []
    i, n, in_str = 0, len(text), False
    while i < n:
        ch = text[i]
        if in_str:
            out.append(ch)
            if ch == "\\" and i + 1 < n:
                out.append(text[i + 1])
                i += 1
            elif ch == '"':
                in_str = False
        elif ch == '"':
            in_str = True
            out.append(ch)
        elif text.startswith("//", i):
            while i < n and text[i] != "\n":
                i += 1
            continue
        elif text.startswith("/*", i):
            end = text.find("*/", i + 2)
            i = n if end == -1 else end + 2
            continue
        else:
            out.append(ch)
        i += 1
    return re.sub(r",(\s*[}\]])", r"\1", "".join(out))


def _mask_jsonc_comments(text: str) -> str:
    """Return `text` with // and /* */ comments blanked out, same length and offsets."""
    out = list(text)
    i, n, in_str = 0, len(text), False
    while i < n:
        ch = text[i]
        if in_str:
            if ch == "\\":
                i += 1
            elif ch == '"':
                in_str = False
        elif ch == '"':
            in_str = True
        elif text.startswith("//", i) or text.startswith("/*", i):
            end = text.find("\n", i) if text.startswith("//", i) else text.find("*/", i + 2)
            stop = n if end == -1 else (end if text.startswith("//", i) else end + 2)
            for k in range(i, stop):
                if out[k] != "\n":
                    out[k] = " "
            i = stop
            continue
        i += 1
    return "".join(out)


def _jsonc_depth(masked: str, position: int) -> int:
    """Brace/bracket nesting depth at `position` of comment-masked text."""
    depth, in_str, i = 0, False, 0
    while i < position:
        ch = masked[i]
        if in_str:
            if ch == "\\":
                i += 1
            elif ch == '"':
                in_str = False
        elif ch == '"':
            in_str = True
        elif ch in "{[":
            depth += 1
        elif ch in "}]":
            depth -= 1
        i += 1
    return depth


_JSONC_SCALAR = r'"(?:[^"\\]|\\.)*"|-?[0-9][0-9.eE+-]*|true|false|null'


def configure_vscode_accessibility(path: Path = DEFAULT_VSCODE_SETTINGS) -> None:
    """Enable VS Code screen-reader accessibility without replacing other settings.

    settings.json is JSONC, so comments and formatting are preserved by editing
    the text in place rather than re-serialising it. A one-time backup is kept.
    Keys and braces are located outside comments, so a commented-out setting or a
    brace in a header comment is never mistaken for the real thing.
    """
    path = path.expanduser()
    # utf-8-sig: editors on Windows may add a BOM, which json.loads rejects.
    text = path.read_text(encoding="utf-8-sig") if path.exists() else "{\n}\n"
    try:
        data = json.loads(_strip_jsonc(text) or "{}")
    except json.JSONDecodeError as exc:
        raise ValueError(f"VS Code settings are not valid JSON: {path}") from exc
    if not isinstance(data, dict):
        raise ValueError(f"VS Code settings must contain a JSON object: {path}")

    wanted = {"editor.accessibilitySupport": "on"}
    if "window.titleBarStyle" not in data:
        wanted["window.titleBarStyle"] = "custom"
    for key, value in wanted.items():
        line = f'"{key}": {json.dumps(value)}'
        masked = _mask_jsonc_comments(text)
        existing = next(
            (
                match
                for match in re.finditer(rf'"{re.escape(key)}"\s*:\s*({_JSONC_SCALAR})', masked)
                if _jsonc_depth(masked, match.start()) == 1
            ),
            None,
        )
        if existing:
            text = text[:existing.start()] + line + text[existing.end():]
            continue
        if key in data:
            raise ValueError(f"cannot edit {key} in place (its value is not a plain value): {path}")
        brace = next(
            (m.start() for m in re.finditer(r"\{", masked) if _jsonc_depth(masked, m.start()) == 0),
            None,
        )
        if brace is None:
            raise ValueError(f"VS Code settings must contain a JSON object: {path}")
        rest = _strip_jsonc(text[brace + 1:]).strip()
        sep = "" if rest.startswith("}") else ","
        text = f"{text[:brace + 1]}\n    {line}{sep}{text[brace + 1:]}"
    try:
        json.loads(_strip_jsonc(text))  # never write something we cannot parse
    except json.JSONDecodeError as exc:
        raise ValueError(f"edited VS Code settings would not be valid JSON; nothing written: {path}") from exc
    path.parent.mkdir(parents=True, exist_ok=True)
    backup = path.with_name(path.name + ".linux-rdaccess-backup")
    if path.exists() and not backup.exists():
        backup.write_bytes(path.read_bytes())
    tmp = path.with_name(path.name + ".linux-rdaccess-tmp")
    tmp.write_text(text, encoding="utf-8")
    os.replace(tmp, path)


def patch_status(orca_config: Path) -> list[tuple[str, str]]:
    """Report whether each legacy Orca Remote patch is active.

    Patches only take effect after ``connect`` re-applies them and Orca restarts.
    """
    base = orca_config.expanduser().parent
    checks = (
        ("input shim (remote_controller.py)", base / LEGACY_REMOTE_CONTROLLER_RELATIVE,
         LEGACY_COMPAT_MARKER, LEGACY_COMPAT_MARKER_V1, legacy_controller_patch_current),
        ("fast key injection (local_machine.py)", base / LEGACY_LOCAL_MACHINE_RELATIVE,
         LOCAL_MACHINE_MARKER, LOCAL_MACHINE_MARKER_V1, legacy_local_machine_patch_current),
    )
    rows = []
    customization_checks = (
        ("native Orca keyboard events (orca-customizations.py)",
         CUSTOMIZATION_EVENT_API_MARKER, legacy_customization_event_api_patch_current),
        ("automatic relay reconnect (orca-customizations.py)",
         CUSTOMIZATION_RECONNECT_MARKER, legacy_customization_reconnect_patch_current),
        ("NVDA speech sequence (orca-customizations.py)",
         CUSTOMIZATION_SPEECH_SEQUENCE_MARKER, legacy_customization_speech_sequence_patch_current),
        ("native Say All callbacks (orca-customizations.py)",
         CUSTOMIZATION_SAY_ALL_CALLBACK_MARKER, legacy_customization_say_all_callback_patch_current),
    )
    try:
        customization = orca_config.expanduser().read_text(encoding="utf-8")
    except OSError:
        rows.extend((label, "missing") for label, _, _ in customization_checks)
    else:
        for label, marker, valid in customization_checks:
            if valid(customization):
                rows.append((label, "current"))
            elif marker in customization:
                rows.append((label, "incomplete patch - repair required"))
            else:
                rows.append((label, "not patched - run: linux-rdaccess connect"))
    for label, path, current, old, valid in checks:
        try:
            text = path.read_text(encoding="utf-8")
        except OSError:
            rows.append((label, "missing"))
            continue
        if current in text:
            rows.append((label, "current" if valid(text) else "incomplete patch - repair required"))
        elif old in text:
            rows.append((label, "outdated - run: linux-rdaccess connect"))
        else:
            rows.append((label, "not patched - run: linux-rdaccess connect"))

    label = "relay transport cleanup (transport.py)"
    transport_path = base / LEGACY_TRANSPORT_RELATIVE
    try:
        transport_text = transport_path.read_text(encoding="utf-8")
    except OSError:
        rows.append((label, "missing"))
    else:
        if legacy_transport_cleanup_patch_current(transport_text):
            rows.append((label, "current"))
        elif (TRANSPORT_PENDING_CONNECT_MARKER not in transport_text
              and _legacy_transport_cleanup_v7_current(transport_text)):
            rows.append((label, "outdated - run: linux-rdaccess connect"))
        elif TRANSPORT_CLEANUP_MARKER in transport_text:
            rows.append((label, "incomplete patch - repair required"))
        elif (TRANSPORT_CLEANUP_MARKER_V1 in transport_text
              or TRANSPORT_CLEANUP_MARKER_V2 in transport_text
              or TRANSPORT_CLEANUP_MARKER_V3 in transport_text
              or TRANSPORT_CLEANUP_MARKER_V4 in transport_text
              or TRANSPORT_CLEANUP_MARKER_V5 in transport_text
              or TRANSPORT_CLEANUP_MARKER_V6 in transport_text):
            rows.append((label, "outdated - run: linux-rdaccess connect"))
        else:
            rows.append((label, "not patched - run: linux-rdaccess connect"))

    label = "Orca API adapter (linux_rdaccess_orca_adapter.py)"
    try:
        installed = (base / "orca-scripts/linux_rdaccess_orca_adapter.py").read_text(encoding="utf-8")
    except OSError:
        rows.append((label, "missing"))
    else:
        try:
            expected = orca_runtime_sources()["orca_adapter"].read_text(encoding="utf-8")
        except OSError:
            rows.append((label, "unknown - CLI adapter source missing"))
        else:
            rows.append((label, "current" if installed == expected else "outdated - run: linux-rdaccess connect"))

    # The adapter imports this for NVDA-native braille; without it that feature
    # silently falls back to raw cells, so report it like the adapter.
    label = "AT-SPI semantic model (linux_rdaccess_a11y_model.py)"
    try:
        installed = (base / "orca-scripts/linux_rdaccess_a11y_model.py").read_text(encoding="utf-8")
    except OSError:
        rows.append((label, "missing"))
    else:
        try:
            expected = orca_runtime_sources()["a11y_model"].read_text(encoding="utf-8")
        except OSError:
            rows.append((label, "unknown - CLI model source missing"))
        else:
            rows.append((label, "current" if installed == expected else "outdated - run: linux-rdaccess connect"))
    label = "Caret diagnostics (linux_rdaccess_caret_diagnostics.py)"
    try:
        installed = (base / "orca-scripts/linux_rdaccess_caret_diagnostics.py").read_text(encoding="utf-8")
    except OSError:
        rows.append((label, "missing"))
    else:
        try:
            expected = orca_runtime_sources()["caret_diagnostics"].read_text(encoding="utf-8")
        except OSError:
            rows.append((label, "unknown - CLI diagnostic source missing"))
        else:
            rows.append((label, "current" if installed == expected else "outdated - run: linux-rdaccess connect"))
    return rows


def _tool_version(command: list[str]) -> str:
    if shutil.which(command[0]) is None:
        return "not found"
    try:
        out = subprocess.run(command, capture_output=True, text=True, timeout=5)
        return (out.stdout or out.stderr).strip().splitlines()[0][:80]
    except (OSError, subprocess.SubprocessError, IndexError):
        return "unknown"


def print_doctor(orca_config: Path) -> None:
    print("linux-rdaccess patch status:")
    for label, status in patch_status(orca_config):
        print(f"  {label}: {status}")
    print("")
    print("Versions:")
    for name, command in (
        ("Orca", ["orca", "--version"]),
        ("Firefox", ["firefox", "--version"]),
        ("speech-dispatcher", ["speech-dispatcher", "--version"]),
        ("xdotool (fallback)", ["xdotool", "version"]),
    ):
        print(f"  {name}: {_tool_version(command)}")
    print("")
    slow = orca_config.expanduser().parent / "orca-remote-slow-events.log"
    count = 0
    try:
        count = len(slow.read_text(encoding="utf-8").splitlines())
    except OSError:
        pass
    print(f"Slow key events logged: {count} ({slow})")
    print("To record stalls, launch Orca with LINUX_RDACCESS_DEBUG=1 (logs timing only,")
    print("never which keys were pressed).")


COMPATIBILITY_APPS = (
    ("thunar", "Thunar File Manager"),
    ("xfce4-terminal", "XFCE Terminal"),
    ("xfce4-settings-manager", "XFCE Settings Manager"),
    ("mousepad", "Mousepad"),
    ("xed", "Xed"),
    ("mintupdate", "Update Manager"),
    ("mintinstall", "Software Manager"),
    ("xfce4-panel", "XFCE panel"),
    ("firefox", "Firefox"),
    ("code", "VS Code"),
)


def compatibility_status() -> list[tuple[str, str, bool]]:
    """Return command availability for the primary Linux Mint compatibility targets."""
    return [
        (command, label, shutil.which(command) is not None)
        for command, label in COMPATIBILITY_APPS
    ]


def print_compatibility_status() -> None:
    print("Linux Mint / XFCE compatibility targets:")
    for command, label, available in compatibility_status():
        print(f"  {label}: {'installed' if available else 'not found'} ({command})")
    print("")
    print("Also test reusable UI patterns:")
    print("  GTK Open/Save dialogs")
    print("  XFCE panel/application menu")
    print("  notifications")
    print("  authentication prompts")
    print("  trees/lists/tables/menus/dialogs/tabs/toolbars")



def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--orca-config", type=Path, default=DEFAULT_ORCA_CONFIG)
    sub = parser.add_subparsers(dest="command", required=True)

    install = sub.add_parser("install", help="install the linux-rdaccess command for this user")
    install.add_argument("--no-autostart", action="store_true")

    sub.add_parser("uninstall", help="remove the user command and autostart entry")

    connect_p = sub.add_parser("connect", help="apply settings and connect Orca Remote")
    connect_p.add_argument("--no-restart", action="store_true")
    connect_p.add_argument("--quiet", action="store_true")

    disconnect_p = sub.add_parser("disconnect", help="disconnect Orca Remote but keep saved settings")
    disconnect_p.add_argument("--no-restart", action="store_true")
    disconnect_p.add_argument("--quiet", action="store_true")

    sub.add_parser("status", help="show redacted Remote Access status")

    autostart = sub.add_parser("autostart", help="enable or disable login autostart")
    autostart.add_argument("state", choices=("enable", "disable", "status"))

    sub.add_parser("shortcuts", help="show common NVDA/Orca shortcuts")
    sub.add_parser("compatibility", help="show Linux Mint application compatibility targets")
    sub.add_parser("doctor", help="check that the NVDA compatibility patches are active")

    vscode = sub.add_parser("vscode-setup", help="enable VS Code Linux screen-reader accessibility")
    vscode.add_argument(
        "--settings",
        type=Path,
        default=DEFAULT_VSCODE_SETTINGS,
        help="path to VS Code settings.json",
    )

    sub.add_parser("configure", help="run the Remote Access configuration manager")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args, forwarded = parser.parse_known_args(argv)
    if forwarded and args.command != "configure":
        parser.error("unrecognized arguments: " + " ".join(forwarded))
    config_path = args.config.expanduser()
    orca_config = args.orca_config.expanduser()

    if args.command == "install":
        source_dir = source_bundle_root()
        install_user_files(source_dir)
        if not args.no_autostart:
            write_autostart()
        print(f"Installed command: {DEFAULT_BIN}")
        print(f"Autostart: {'disabled' if args.no_autostart else 'enabled'}")
        print("If ~/.local/bin is not already in PATH, log out and back in or add it to PATH.")
        return 0

    if args.command == "uninstall":
        remove_autostart()
        try:
            DEFAULT_BIN.unlink()
        except FileNotFoundError:
            pass
        if DEFAULT_SHARE_DIR.exists():
            shutil.rmtree(DEFAULT_SHARE_DIR)
        print("Removed the linux-rdaccess command and autostart entry.")
        print("Saved Remote Access configuration was kept.")
        return 0

    if args.command == "connect":
        return connect(
            config_path=config_path,
            orca_config=orca_config,
            restart=not args.no_restart,
            quiet=args.quiet,
        )

    if args.command == "disconnect":
        return disconnect(
            orca_config=orca_config,
            restart=not args.no_restart,
            quiet=args.quiet,
        )

    if args.command == "status":
        config = load_config(config_path)
        print_status(config)
        print(f"autostart_enabled: {DEFAULT_AUTOSTART.exists()}")
        print(f"command_installed: {DEFAULT_BIN.exists()}")
        print(f"orca_remote_config_found: {orca_config.exists()}")
        return 0 if config.ready else 1

    if args.command == "autostart":
        if args.state == "enable":
            write_autostart()
            print("Enabled linux-rdaccess autostart.")
        elif args.state == "disable":
            remove_autostart()
            print("Disabled linux-rdaccess autostart.")
        else:
            print("enabled" if DEFAULT_AUTOSTART.exists() else "disabled")
        return 0

    if args.command == "doctor":
        print_doctor(args.orca_config)
        return 0

    if args.command == "compatibility":
        print_compatibility_status()
        return 0

    if args.command == "shortcuts":
        print("Windows NVDA:")
        print("  Insert+Alt+Tab    Toggle local/remote computer control")
        print("")
        print("NVDA commands translated on Linux (desktop layout):")
        print("  NVDA+Up / NVDA+Down              Current caret line / say all")
        print("  NVDA+Space                       Browse/focus mode")
        print("  NVDA+Tab / NVDA+T / NVDA+End      Where am I / title / status bar")
        print("  NVDA+F12                         Time; twice quickly for date")
        print("  NVDA+F7                          Elements list")
        print("  Ctrl+Alt+Arrows                   Table cells in web browse mode")
        print("")
        print("Legacy Orca Remote:")
        print("  Orca+Alt+PageUp / Orca+Alt+C      Connect")
        print("  Orca+Alt+PageDown / Orca+Alt+D    Disconnect")
        print("  Orca+Alt+M                         Mute/unmute remote output")
        return 0

    if args.command == "vscode-setup":
        try:
            configure_vscode_accessibility(args.settings)
        except ValueError as exc:
            print(exc)
            return 1
        print(f"Enabled VS Code screen-reader accessibility in: {args.settings.expanduser()}")
        print("If Orca is still silent, launch VS Code with: ACCESSIBILITY_ENABLED=1 code")
        return 0

    if args.command == "configure":
        remote_access = source_bundle_root() / "remote_access.py"
        return subprocess.call([sys.executable, str(remote_access), "--config", str(config_path), "configure", *forwarded])

    return 2


if __name__ == "__main__":
    raise SystemExit(main())
