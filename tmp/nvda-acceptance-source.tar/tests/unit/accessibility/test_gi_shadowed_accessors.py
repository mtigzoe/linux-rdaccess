"""Regression coverage for libatspi 2.50+ Accessible alias collisions."""
import sys
import types
import unittest
from unittest.mock import patch

from linux_rdaccess_core.accessibility import a11y_model


class ShadowedAccessible:
    def __init__(self):
        self.text = "hello world"
        self.current = 42.0
        self.value_text = ""

    def get_text_iface(self):
        return self

    def get_value_iface(self):
        return self

    def get_character_count(self):
        return len(self.text)

    def get_caret_offset(self):
        return 4

    def get_n_selections(self):
        return 1

    # Accessible aliases shadow Text/Value methods in newer libatspi.
    def get_text(self):
        raise AssertionError("Accessible.get_text alias was used")

    def get_selection(self):
        raise AssertionError("Accessible.get_selection alias was used")

    def get_current_value(self):
        raise AssertionError("Accessible.get_current_value must be bypassed")


class TextInterface:
    @staticmethod
    def get_text(obj, start, end):
        return obj.text[start:end]

    @staticmethod
    def get_selection(obj, index):
        return (2, 5) if index == 0 else None


class ValueInterface:
    @staticmethod
    def get_text(obj):
        return obj.value_text

    @staticmethod
    def get_current_value(obj):
        return obj.current


class ShadowedAccessorTests(unittest.TestCase):
    def setUp(self):
        gi = types.ModuleType("gi")
        repository = types.ModuleType("gi.repository")
        repository.Atspi = types.SimpleNamespace(
            Accessible=ShadowedAccessible, Text=TextInterface, Value=ValueInterface
        )
        gi.repository = repository
        self.modules = patch.dict(sys.modules, {"gi": gi, "gi.repository": repository})
        self.modules.start()
        self.addCleanup(self.modules.stop)

    def test_text_snapshot_uses_text_interface_and_preserves_caret(self):
        result = a11y_model._text_snapshot(ShadowedAccessible(), focused=True)
        self.assertEqual(result["text"], "hello world")
        self.assertEqual(result["caret_offset"], 4)
        self.assertTrue(result["text_supported"])
        self.assertFalse(result["text_truncated"])

    def test_selection_uses_text_interface(self):
        result = a11y_model._text_snapshot(ShadowedAccessible(), focused=True)
        self.assertEqual((result["selection_start"], result["selection_end"]), (2, 5))

    def test_unicode_gi_selection_offsets_are_preserved_verbatim(self):
        from gi.repository import Atspi
        obj = ShadowedAccessible()
        obj.text = "a🙂 café omega"
        # Cover both GI range properties and the tuple spelling. A provider
        # endpoint of 12 is a real partial selection, not a UTF-16 hint.
        for end in (12, 13):
            for selection in ((0, end), types.SimpleNamespace(start_offset=0, end_offset=end)):
                with self.subTest(end=end, selection_type=type(selection).__name__), patch.object(
                        Atspi.Text, "get_selection", return_value=selection):
                    result = a11y_model._text_snapshot(obj, focused=True)
                self.assertEqual(result["text"], obj.text)
                self.assertEqual((result["selection_start"], result["selection_end"]), (0, end))

    def test_value_uses_value_interface_instead_of_accessible_alias(self):
        self.assertEqual(a11y_model._value(ShadowedAccessible()), "42")

    def test_value_interface_text_takes_precedence(self):
        obj = ShadowedAccessible()
        obj.value_text = "Loud"
        obj.current = 3.0
        self.assertEqual(a11y_model._value(obj), "Loud")

    def test_empty_text_is_not_truncated(self):
        obj = ShadowedAccessible()
        obj.text = ""
        result = a11y_model._text_snapshot(obj, focused=True)
        self.assertEqual(result["text"], "")
        self.assertFalse(result["text_truncated"])

    def test_missing_gi_value_method_does_not_crash_snapshot(self):
        # Older/newer GI typelib bindings can omit interface methods.
        from gi.repository import Atspi
        old_value = Atspi.Value
        Atspi.Value = types.SimpleNamespace(get_text=lambda obj: "")
        try:
            self.assertEqual(a11y_model._value(ShadowedAccessible()), "")
        finally:
            Atspi.Value = old_value

    def test_incompatible_gi_text_method_does_not_crash_snapshot(self):
        from gi.repository import Atspi
        old_text = Atspi.Text
        Atspi.Text = types.SimpleNamespace(
            get_text=lambda obj: (_ for _ in ()).throw(TypeError("incompatible")),
            get_selection=old_text.get_selection,
        )
        try:
            result = a11y_model._text_snapshot(ShadowedAccessible(), focused=True)
            self.assertEqual(result["text"], "")
            self.assertTrue(result["text_truncated"])
        finally:
            Atspi.Text = old_text

    def test_non_gi_value_object_repr_is_not_reported(self):
        class FakeValue:
            def get_text(self):
                return object()

            def get_current_value(self):
                return 7.0

        class FakeAccessible:
            def get_value_iface(self):
                return FakeValue()

        self.assertEqual(a11y_model._value(FakeAccessible()), "7")

    def test_failed_optional_value_description_keeps_the_numeric_value(self):
        from gi.repository import Atspi
        for error in (NotImplementedError("unsupported"), RuntimeError("provider unavailable")):
            with self.subTest(error=type(error).__name__), patch.object(
                    Atspi.Value, "get_text", side_effect=error):
                self.assertEqual(a11y_model._value(ShadowedAccessible()), "42")

    def test_failed_numeric_value_query_does_not_discard_the_focus_snapshot(self):
        from gi.repository import Atspi
        from tests.unit.accessibility.test_a11y_model import FakeAccessible
        obj = FakeAccessible("Slider", "slider", value_iface=ShadowedAccessible())
        with patch.object(Atspi.Value, "get_current_value", side_effect=RuntimeError("provider unavailable")):
            payload = a11y_model.build_focus_payload("object:state-changed:focused", 1, obj)
        focus = next(item for item in payload["objects"] if item["id"] == payload["focus_id"])
        self.assertEqual(focus["name"], "Slider")
        self.assertEqual(focus["value"], "")

    def test_failed_selection_query_keeps_text_and_caret(self):
        from gi.repository import Atspi
        with patch.object(Atspi.Text, "get_selection", side_effect=RuntimeError("provider unavailable")):
            result = a11y_model._text_snapshot(ShadowedAccessible(), focused=True)
        self.assertEqual(result["text"], "hello world")
        self.assertEqual(result["caret_offset"], 4)
        self.assertIsNone(result["selection_start"])
        self.assertIsNone(result["selection_end"])



if __name__ == "__main__":
    unittest.main()
