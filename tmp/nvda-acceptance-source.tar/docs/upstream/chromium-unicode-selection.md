# Chromium Unicode selection candidate

The later [private native experiment](../compatibility-audit-2026-10-15-native-chromium-selection.md)
tests a compiled-method counterpart to the correction. It adds native
application evidence; the full source build and upstream gtests remain unrun.

`chromium-unicode-selection.diff` is an **unsubmitted upstream candidate** for
Chromium `150.0.7871.250`. Chromium source and patch context are covered by the
included [BSD license](Chromium-LICENSE.txt). This repository does not build or
install a patched Chromium/Electron binary.

The test host's installed Code 1.141.0 reports Electron `43.7.7`, Chromium
`150.0.7871.250`, and Microsoft build `15553055` when its executable runs in
Node-only mode. [Electron's version-pinned DEPS][deps] agrees with this Chromium
version. None of the 319 `.patch` files under Electron v43.7.7's
`patches/chromium` mentions `ax_platform_node_auralinux`.

In the [pinned Chromium provider source][provider], `GetSelectionExtents`
converts UTF-16 selection offsets into Unicode character offsets.
`GetSelectionWithText` then converts those results again. For a selection that
ends after one supplementary character, 14 UTF-16 units become 13 characters,
then 12. Two supplementary characters produce 16 → 14 → 12. The separate
caret getter converts once.

The candidate converts only the find-in-page fallback, whose stored offsets
remain UTF-16. It preserves the already converted ordinary selection extents.
Three proposed upstream gtests cover supplementary characters, partial and
reversed selections, two supplementary characters, and find-in-page.

The source-extraction contract compiles the **actual two selection methods**
with explicit test dependencies for ATK, selection storage, text retrieval,
and Unicode conversion. It checks full and partial selections, a supplementary
character selected alone, reversed extents, two supplementary characters,
find-in-page fallback, and no selection. It checks both returned offsets and
selected text.

On the Linux Mint test host, g++ 11.4.0 compiled both versions with
`-std=c++17 -Wall -Wextra -Werror`:

| Source | Passed | Failed | Executable exit status |
| --- | ---: | ---: | ---: |
| Original | 4 | 5 | 1 |
| Candidate | 9 | 0 | 0 |

The contract succeeds only when it observes exactly those original failures
and all candidate cases pass. It verifies the source SHA-256 before creating
output:
`1d50dc6645c011e6fa2f036c2b08f7bb35967a60dbda12d52d55e901e8dd731f`.
It writes per-case numeric JSONL, a summary, extracted C++, and executables to
a new output directory. The evidence from 2026-10-15 is retained on the host
under `/tmp/lrd-chromium-selection-20261015.5ynYuk/result`.

From the repository root on Linux, with g++, git, and curl available:

```sh
mkdir -p /tmp/lrd-chromium-selection-source
curl --fail --location 'https://raw.githubusercontent.com/chromium/chromium/150.0.7871.250/ui/accessibility/platform/ax_platform_node_auralinux.cc' -o /tmp/lrd-chromium-selection-source/ax_platform_node_auralinux.cc
python3 tools/diagnostics/chromium_selection_contract.py --source /tmp/lrd-chromium-selection-source/ax_platform_node_auralinux.cc --patch docs/upstream/chromium-unicode-selection.diff --output /tmp/lrd-chromium-selection-contract
```

Choose a new `--output` path for each invocation. The contract does not fetch
source or contact a desktop. Its output does not establish a full Chromium
build, execution of the proposed upstream gtests, a native test of the C++
candidate, or NVDA/physical braille acceptance. Those checks remain outstanding.
The separate native observation establishes that the Unicode offset defect
also occurs in private original and experimentally patched VS Code copies;
it does not establish native acceptance of this Chromium candidate.

[deps]: https://raw.githubusercontent.com/electron/electron/v43.7.7/DEPS
[provider]: https://raw.githubusercontent.com/chromium/chromium/150.0.7871.250/ui/accessibility/platform/ax_platform_node_auralinux.cc
